# -*- coding: utf-8 -*-
{
    'name': "Website info",  # Module title
    'summary': "Override Website info",  # Module subtitle phrase
    'author': "Parth Gajjar",
    'category': 'Uncategorized',
    'version': '12.0.1',
    'depends': ['website'],
    'data': [
        'views/templates.xml'
    ],
}
