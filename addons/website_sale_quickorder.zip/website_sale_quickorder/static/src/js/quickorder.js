odoo.define('website_sale_quickorder.quickorder', function (require) {
'use strict';

var publicWidget = require('web.public.widget');
var core = require('web.core');
var concurrency = require('web.concurrency');
var qweb = core.qweb;

publicWidget.registry.AddInQuickOrderList = publicWidget.Widget.extend({
  selector: '.o_wsale_products_searchbar_form',
  events: {
    'click .pro-item': '_OnClick'
  },

  _OnClick: function (event) {
    console.log('=================')
    var div =  event.target;
    console.log(div)
    div = $(div).closest('.pro-item')
    this.id = $(div).data('id')
    this.src = $(div).data('src')
    this.price = $(div).data('price')
    this.name = $(div).data('name')
    var html = '<tr data-id="' + this.id + '">\
                    <td>\
                      <img src="' + this.src + '" class="flex-shrink-0 o_image_64_contain" />\
                      <span>'+ this.name +'</span>\
                    </td>\
                    <td>\
                      <input class="form-control w-25" value="1" placeholder="qty" />\
                    </td>\
                    <td>\
                      100\
                    </td>\
                    <td>' + this.price + '\
                    </td>\
                    <td>\
                      <button type="button" class="btn btn-danger btn-circle btn-circle remove"> x </button>\
                    </td>\
                </tr>'
    $('.first-tr').remove()
    $('#quick-order-table > tbody').append(html)
  }
})

publicWidget.registry.RemoveQuickOrderItem = publicWidget.Widget.extend({
  selector: '#quick-order-table',
  events: {
    'click .remove': '_OnBtnClick'
  },

  _OnBtnClick: function (event) {
    var btn = event.target
    $(btn).closest('tr').remove()
    const trlen = $('#quick-order-table > tbody tr').length;
    if (trlen === 0) {
      var html = `<tr class="first-tr">
                    <td colspan="5">
                      <h3 class="my-3 text-center">No products available</h3>
                    </td>
                  </tr>`
      $('#quick-order-table > tbody').append(html);
    }
  }
})

publicWidget.registry.quickOrderSearch = publicWidget.Widget.extend({
    selector: '.o_wsale_products_searchbar_form',
    xmlDependencies: ['/website_sale_quickorder/static/src/xml/productDropdown.xml'],
    events: {
      'input .quick-search': '_onInput',
      'focusout': '_onFocusOut',
      'keydown .quick-search': '_onKeydown'
    },
    autocompleteMinWidth: 300,
    /**
    * @constructor
    */
    init: function () {
      this._super.apply(this, arguments);
      this._dp = new concurrency.DropPrevious();
      this._onInput = _.debounce(this._onInput, 400)
      this._onFocusOut = _.debounce(this._onFocusOut, 100)
    },
    /**
    * @override
    **/
    start: function () {
      this.$input = this.$('.quick-search')
      this.order = this.$('.o_wsale_search_order_by').val();
      this.limit = parseInt(this.$input.data('limit'));
      this.displayDescription = !!this.$input.data('displayDescription');
      this.displayPrice = !!this.$input.data('displayPrice')
      this.displayImage = !!this.$input.data('displayImage')

      if (this.limit) {
          this.$input.attr('autocomplete', 'off');
      }

      return this._super.apply(this, arguments)
    },

    _fetch: function () {
      return this._rpc({
        route:  '/shop/products/autocomplete',
        params: {
            'term': this.$input.val(),
            'options': {
                'order': this.order,
                'limit': this.limit,
                'display_description': this.displayDescription,
                'display_price': this.displayPrice,
                'max_nb_chars': Math.round(Math.max(this.autocompleteMinWidth, parseInt(this.$el.width())) * 0.22),
            },
        },
      })
    },

    _render: function (res) {
      var $prevMenu = this.$menu
      this.$el.toggleClass('dropdown show', !!res);
      if (res) {
        var products = res['products'];
        this.$menu = $(qweb.render('website_sale_quickorder.productsSearchBar.autocomplete', {
          products: products,
          hasMoreProducts: products.length < res['products_count'],
          currency: res['currency'],
          widget: this,
        }));
        this.$menu.css('min-width', this.autocompleteMinWidth)
        this.$el.append(this.$menu)
      }
      if ($prevMenu) {
        $prevMenu.remove();
      }
    },

    _onInput: function () {
      if (!this.limit) {
        return;
      }
      this._dp.add(this._fetch()).then(this._render.bind(this));
    },

    _onFocusOut: function () {
      if (!this.$el.has(document.activeElement).length) {
        this._render();
      }
    },

    _onKeydown: function (ev) {
        switch (ev.which) {
            case $.ui.keyCode.ESCAPE:
                this._render();
                break;
            case $.ui.keyCode.UP:
            case $.ui.keyCode.DOWN:
                ev.preventDefault();
              if (this.$menu) {
                  let $element = ev.which === $.ui.keyCode.UP ? this.$menu.children().last() : this.$menu.children().first();
                  $element.focus();
              }
              break;
        }
    },
  })
});
