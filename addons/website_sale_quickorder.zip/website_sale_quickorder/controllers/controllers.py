# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request

class WebsiteSaleQuickorder(http.Controller):
    @http.route('/my/quick-order', type='http', auth="public", website=True)
    def index(self, **kw):
        dictV = {}
        dictV['page'] = 'quickorder'
        return request.render("website_sale_quickorder.index", dictV)

    # @http.route('/website_sale_quickorder/website_sale_quickorder/objects/', auth='public')
    # def list(self, **kw):
    #     return http.request.render('website_sale_quickorder.listing', {
    #         'root': '/website_sale_quickorder/website_sale_quickorder',
    #         'objects': http.request.env['website_sale_quickorder.website_sale_quickorder'].search([]),
    #     })

    # @http.route('/website_sale_quickorder/website_sale_quickorder/objects/<model("website_sale_quickorder.website_sale_quickorder"):obj>/', auth='public')
    # def object(self, obj, **kw):
    #     return http.request.render('website_sale_quickorder.object', {
    #         'object': obj
    #     })
